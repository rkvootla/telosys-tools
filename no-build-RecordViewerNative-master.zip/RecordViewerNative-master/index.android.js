/**
 * Record Viewer React Native App
 */
import { AppRegistry } from 'react-native'
import Root from './Root'

AppRegistry.registerComponent("recordviewernative", () => Root)
//registerRootComponent(Root);
