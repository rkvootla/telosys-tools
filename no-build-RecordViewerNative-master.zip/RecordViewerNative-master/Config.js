// Update with configuration for your org and connected app.

const Config = {
  loginUrl: 'https://login.salesforce.com/services/oauth2/authorize?',
  consumerKey: '3MVG9GYWKbMgBvby7vfqqOxolL.wBMfjEbYtulfuyT50G7ceVHZg_mETvLgHQeJdDxnNocYO8tDw9Tvcv09pW',
  oauthRedirect: 'http://localhost:3001/oauth-redirect'
}

export default Config
